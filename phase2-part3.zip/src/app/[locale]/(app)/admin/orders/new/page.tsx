import { getLocale, getTranslations } from 'next-intl/server';
import { ChevronLeft, Store } from 'lucide-react';
import { Link } from '@/i18n/navigation';
import { createClient } from '@/lib/supabase/server';
import { getOrderFormData } from '@/lib/orders';
import { isUuid } from '@/lib/forms';
import { EmptyState, PageHeader } from '@/components/ui/page-parts';
import { OrderForm } from '@/components/orders/order-form';

export async function generateMetadata() {
  const t = await getTranslations('orders.onBehalf');
  return { title: t('title') };
}

// طلب تسجله الإدارة نيابة عن محل (وصل بالهاتف أو واتساب): اختيار المحل ثم نفس نموذج الطلب.
// القاعدة تتحقق أن المنشئ إدارة وأن المحل مفعّل، وتطبق نفس قواعد المواعيد والطاقة.
export default async function AdminNewOrderPage({ searchParams }: { searchParams: Promise<{ customer?: string }> }) {
  const locale = await getLocale();
  const t = await getTranslations('orders.onBehalf');
  const { customer } = await searchParams;
  const supabase = await createClient();
  const ar = locale === 'ar';
  const back = { href: '/admin/orders', label: t('back') };

  if (customer && isUuid(customer)) {
    const { data: shop } = await supabase.from('customers').select('id, name_ar, name_en, is_active').eq('id', customer).maybeSingle();
    if (shop?.is_active) {
      const data = await getOrderFormData(shop.id);
      return (
        <section>
          <PageHeader
            title={t('titleFor', { shop: ar ? shop.name_ar : shop.name_en })}
            description={t('description')}
            back={{ href: '/admin/orders/new', label: t('changeShop') }}
          />
          <OrderForm data={data} mode="create" basePath="/admin/orders" customerId={shop.id} />
        </section>
      );
    }
  }

  const { data } = await supabase.from('customers').select('id, name_ar, name_en, contact_name').eq('is_active', true).order(ar ? 'name_ar' : 'name_en');
  const shops = (data ?? []) as { id: string; name_ar: string; name_en: string; contact_name: string | null }[];

  return (
    <section className="max-w-3xl">
      <PageHeader title={t('title')} description={t('chooseShop')} back={back} />
      {shops.length === 0 ? (
        <EmptyState
          icon={<Store className="h-6 w-6" aria-hidden />}
          title={t('noShops')}
          action={<Link href="/admin/customers/new" className="btn-primary">{t('addShop')}</Link>}
        />
      ) : (
        <ul className="grid gap-2 sm:grid-cols-2">
          {shops.map((s) => (
            <li key={s.id}>
              <Link href={`/admin/orders/new?customer=${s.id}`} className="card flex items-center gap-3 p-4 hover:border-primary">
                <Store className="h-5 w-5 shrink-0" aria-hidden />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-bold">{ar ? s.name_ar : s.name_en}</span>
                  {s.contact_name && <span className="block truncate text-sm text-ink-muted">{s.contact_name}</span>}
                </span>
                <ChevronLeft className="h-5 w-5 shrink-0 text-ink-muted ltr:-scale-x-100" aria-hidden />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
