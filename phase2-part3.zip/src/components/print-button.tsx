'use client';

import { Printer } from 'lucide-react';

// زر طباعة الصفحة الحالية. القوائم والأزرار مخفية في الطباعة (print:hidden)
export function PrintButton({ label }: { label: string }) {
  return (
    <button type="button" onClick={() => window.print()} className="btn-ghost print:hidden">
      <Printer className="h-4 w-4" aria-hidden />
      {label}
    </button>
  );
}
